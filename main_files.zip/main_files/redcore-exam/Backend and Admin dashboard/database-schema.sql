-- Column `CREATE` of type `SCHEMA`; NULLs permitted to simplify development
CREATE SCHEMA public;


-- Column `ALTER` of type `SCHEMA`; NULLs permitted to simplify development
ALTER SCHEMA public OWNER TO red;

--
-- TOC entry 873 (class 1247 OID 16557)
-- Name: clinic_type_enum; Type: TYPE; Schema: public; Owner: red
--

-- Enum `public.clinic_type_enum`: defines a fixed set of possible values
CREATE TYPE public.clinic_type_enum AS ENUM (
    'Public',
    'Private',
    'Mixed'
);


-- Column `ALTER` of type `TYPE`; NULLs permitted to simplify development
ALTER TYPE public.clinic_type_enum OWNER TO red;

--
-- TOC entry 876 (class 1247 OID 16564)
-- Name: identifier_type_enum; Type: TYPE; Schema: public; Owner: red
--

-- Enum `public.identifier_type_enum`: defines a fixed set of possible values
CREATE TYPE public.identifier_type_enum AS ENUM (
    'SUS',
    'SSN',
    'Insurance_ID',
    'Passport_Number',
    'CPF'
);


-- Column `ALTER` of type `TYPE`; NULLs permitted to simplify development
ALTER TYPE public.identifier_type_enum OWNER TO red;

--
-- TOC entry 879 (class 1247 OID 16576)
-- Name: patient_status_enum; Type: TYPE; Schema: public; Owner: red
--

-- Enum `public.patient_status_enum`: defines a fixed set of possible values
CREATE TYPE public.patient_status_enum AS ENUM (
    'active',
    'inactive',
    'deceased'
);


-- Column `ALTER` of type `TYPE`; NULLs permitted to simplify development
ALTER TYPE public.patient_status_enum OWNER TO red;

--
-- TOC entry 882 (class 1247 OID 16584)
-- Name: professional_identifier_enum; Type: TYPE; Schema: public; Owner: red
--

-- Enum `public.professional_identifier_enum`: defines a fixed set of possible values
CREATE TYPE public.professional_identifier_enum AS ENUM (
    'CRM',
    'State_Medical_License',
    'DEA',
    'NPI',
    'License',
    'Certification'
);


-- Column `ALTER` of type `TYPE`; NULLs permitted to simplify development
ALTER TYPE public.professional_identifier_enum OWNER TO red;

--
-- TOC entry 885 (class 1247 OID 16598)
-- Name: status_enum; Type: TYPE; Schema: public; Owner: red
--

-- Enum `public.status_enum`: defines a fixed set of possible values
CREATE TYPE public.status_enum AS ENUM (
    'active',
    'inactive'
);


-- Column `ALTER` of type `TYPE`; NULLs permitted to simplify development
ALTER TYPE public.status_enum OWNER TO red;

-- Column `SET` of type `default_tablespace`; NULLs permitted to simplify development
SET default_tablespace = '';

-- Column `SET` of type `default_table_access_method`; NULLs permitted to simplify development
SET default_table_access_method = heap;

--
-- TOC entry 238 (class 1259 OID 16813)
-- Name: api_keys; Type: TABLE; Schema: public; Owner: red
--

-- Table `public.api_keys`: holds structured data for Api keys
CREATE TABLE public.api_keys (
-- Column `id` of type `uuid`; NULLs permitted to simplify development
    id uuid DEFAULT gen_random_uuid() NOT NULL,
-- Column `token` of type `character`; NULLs permitted to simplify development
    token character varying(400) NOT NULL,
-- Column `system_id` of type `uuid`; NULLs permitted to simplify development
    system_id uuid NOT NULL,
-- Column `permissions` of type `text`; NULLs permitted to simplify development
    permissions text
);


-- Column `ALTER` of type `TABLE`; NULLs permitted to simplify development
ALTER TABLE public.api_keys OWNER TO red;

--
-- TOC entry 216 (class 1259 OID 16603)
-- Name: appointments; Type: TABLE; Schema: public; Owner: red
--

-- Table `public.appointments`: holds structured data for Appointments
CREATE TABLE public.appointments (
-- Column `id` of type `uuid`; NULLs permitted to simplify development
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
-- Column `clinic_id` of type `uuid`; NULLs permitted to simplify development
    clinic_id uuid NOT NULL,
-- Column `patient_id` of type `uuid`; NULLs permitted to simplify development
    patient_id uuid NOT NULL,
-- Column `doctor_id` of type `uuid`; NULLs permitted to simplify development
    doctor_id uuid NOT NULL,
-- Column `date` of type `timestamp`; NULLs permitted to simplify development
    date timestamp with time zone NOT NULL,
-- Column `created_at` of type `timestamp`; NULLs permitted to simplify development
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
-- Column `updated_at` of type `timestamp`; NULLs permitted to simplify development
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


-- Column `ALTER` of type `TABLE`; NULLs permitted to simplify development
ALTER TABLE public.appointments OWNER TO red;

--
-- TOC entry 217 (class 1259 OID 16608)
-- Name: care_link; Type: TABLE; Schema: public; Owner: red
--

-- Table `public.care_link`: holds structured data for Care link
CREATE TABLE public.care_link (
-- Column `id` of type `uuid`; NULLs permitted to simplify development
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
-- Column `clinic_id` of type `uuid`; NULLs permitted to simplify development
    clinic_id uuid NOT NULL,
-- Column `doctor_id` of type `uuid`; NULLs permitted to simplify development
    doctor_id uuid NOT NULL,
-- Column `patient_id` of type `uuid`; NULLs permitted to simplify development
    patient_id uuid NOT NULL,
-- Column `status` of type `public`; NULLs permitted to simplify development
    status public.status_enum DEFAULT 'active'::public.status_enum
);


-- Column `ALTER` of type `TABLE`; NULLs permitted to simplify development
ALTER TABLE public.care_link OWNER TO red;

--
-- TOC entry 218 (class 1259 OID 16613)
-- Name: clinics; Type: TABLE; Schema: public; Owner: red
--

-- Table `public.clinics`: holds structured data for Clinics
CREATE TABLE public.clinics (
-- Column `id` of type `uuid`; NULLs permitted to simplify development
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
-- Column `name` of type `character`; NULLs permitted to simplify development
    name character varying(100) NOT NULL,
-- Column `address` of type `text`; NULLs permitted to simplify development
    address text NOT NULL,
-- Column `phone` of type `character`; NULLs permitted to simplify development
    phone character varying(20) NOT NULL,
-- Column `email` of type `character`; NULLs permitted to simplify development
    email character varying(255),
-- Column `website` of type `character`; NULLs permitted to simplify development
    website character varying(255),
-- Column `clinic_type` of type `public`; NULLs permitted to simplify development
    clinic_type public.clinic_type_enum DEFAULT 'Private'::public.clinic_type_enum NOT NULL,
-- Column `created_at` of type `timestamp`; NULLs permitted to simplify development
    created_at timestamp without time zone,
-- Column `system_id` of type `uuid`; NULLs permitted to simplify development
    system_id uuid,
-- Column `external_id` of type `character`; NULLs permitted to simplify development
    external_id character varying
);


-- Column `ALTER` of type `TABLE`; NULLs permitted to simplify development
ALTER TABLE public.clinics OWNER TO red;

--
-- TOC entry 219 (class 1259 OID 16620)
-- Name: employment_link; Type: TABLE; Schema: public; Owner: red
--

-- Table `public.employment_link`: holds structured data for Employment link
CREATE TABLE public.employment_link (
-- Column `id` of type `integer`; NULLs permitted to simplify development
    id integer NOT NULL,
-- Column `clinic_id` of type `uuid`; NULLs permitted to simplify development
    clinic_id uuid NOT NULL,
-- Column `doctor_id` of type `uuid`; NULLs permitted to simplify development
    doctor_id uuid NOT NULL,
-- Column `created_at` of type `timestamp`; NULLs permitted to simplify development
    created_at timestamp without time zone DEFAULT now()
);


-- Column `ALTER` of type `TABLE`; NULLs permitted to simplify development
ALTER TABLE public.employment_link OWNER TO red;

--
-- TOC entry 220 (class 1259 OID 16624)
-- Name: employment_link_id_seq; Type: SEQUENCE; Schema: public; Owner: red
--

-- Column `CREATE` of type `SEQUENCE`; NULLs permitted to simplify development
CREATE SEQUENCE public.employment_link_id_seq
-- Column `AS` of type `integer`; NULLs permitted to simplify development
    AS integer
-- Column `START` of type `WITH`; NULLs permitted to simplify development
    START WITH 1
-- Column `INCREMENT` of type `BY`; NULLs permitted to simplify development
    INCREMENT BY 1
-- Column `NO` of type `MINVALUE`; NULLs permitted to simplify development
    NO MINVALUE
-- Column `NO` of type `MAXVALUE`; NULLs permitted to simplify development
    NO MAXVALUE
    CACHE 1;


-- Column `ALTER` of type `SEQUENCE`; NULLs permitted to simplify development
ALTER SEQUENCE public.employment_link_id_seq OWNER TO red;

--
-- TOC entry 3557 (class 0 OID 0)
-- Dependencies: 220
-- Name: employment_link_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: red
--

-- Column `ALTER` of type `SEQUENCE`; NULLs permitted to simplify development
ALTER SEQUENCE public.employment_link_id_seq OWNED BY public.employment_link.id;


--
-- TOC entry 237 (class 1259 OID 16806)
-- Name: external_systems; Type: TABLE; Schema: public; Owner: red
--

-- Table `public.external_systems`: holds structured data for External systems
CREATE TABLE public.external_systems (
-- Column `id` of type `uuid`; NULLs permitted to simplify development
    id uuid DEFAULT gen_random_uuid() NOT NULL,
-- Column `name` of type `character`; NULLs permitted to simplify development
    name character varying(200) NOT NULL,
-- Column `active` of type `boolean`; NULLs permitted to simplify development
    active boolean DEFAULT true
);


-- Column `ALTER` of type `TABLE`; NULLs permitted to simplify development
ALTER TABLE public.external_systems OWNER TO red;

--
-- TOC entry 221 (class 1259 OID 16625)
-- Name: front_desk_users; Type: TABLE; Schema: public; Owner: red
--

-- Table `public.front_desk_users`: holds structured data for Front desk users
CREATE TABLE public.front_desk_users (
-- Column `id` of type `uuid`; NULLs permitted to simplify development
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
-- Column `is_admin` of type `boolean`; NULLs permitted to simplify development
    is_admin boolean NOT NULL,
-- Column `clinic_id` of type `uuid`; NULLs permitted to simplify development
    clinic_id uuid NOT NULL,
-- Column `email` of type `character`; NULLs permitted to simplify development
    email character varying(255) NOT NULL,
-- Column `created_at` of type `timestamp`; NULLs permitted to simplify development
    created_at timestamp without time zone,
-- Column `address` of type `text`; NULLs permitted to simplify development
    address text
);


-- Column `ALTER` of type `TABLE`; NULLs permitted to simplify development
ALTER TABLE public.front_desk_users OWNER TO red;

--
-- TOC entry 222 (class 1259 OID 16631)
-- Name: healthcare_professionals; Type: TABLE; Schema: public; Owner: red
--

-- Table `public.healthcare_professionals`: holds structured data for Healthcare professionals
CREATE TABLE public.healthcare_professionals (
-- Column `id` of type `uuid`; NULLs permitted to simplify development
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
-- Column `profession` of type `character`; NULLs permitted to simplify development
    profession character varying(50),
-- Column `full_name` of type `character`; NULLs permitted to simplify development
    full_name character varying(300) NOT NULL,
-- Column `specialty` of type `character`; NULLs permitted to simplify development
    specialty character varying(100),
-- Column `email` of type `character`; NULLs permitted to simplify development
    email character varying(255) NOT NULL,
-- Column `phone` of type `character`; NULLs permitted to simplify development
    phone character varying(20),
-- Column `clinic_id` of type `uuid`; NULLs permitted to simplify development
    clinic_id uuid NOT NULL,
-- Column `external_id` of type `bigint`; NULLs permitted to simplify development
    external_id bigint,
-- Column `system_id` of type `uuid`; NULLs permitted to simplify development
    system_id uuid
);


-- Column `ALTER` of type `TABLE`; NULLs permitted to simplify development
ALTER TABLE public.healthcare_professionals OWNER TO red;

--
-- TOC entry 223 (class 1259 OID 16637)
-- Name: medical_records; Type: TABLE; Schema: public; Owner: red
--

-- Table `public.medical_records`: holds structured data for Medical records
CREATE TABLE public.medical_records (
-- Column `id` of type `uuid`; NULLs permitted to simplify development
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
-- Column `record_date` of type `timestamp`; NULLs permitted to simplify development
    record_date timestamp without time zone,
-- Column `diagnosis` of type `text`; NULLs permitted to simplify development
    diagnosis text NOT NULL,
-- Column `anamnesis` of type `text`; NULLs permitted to simplify development
    anamnesis text NOT NULL,
-- Column `evolution` of type `text`; NULLs permitted to simplify development
    evolution text NOT NULL,
-- Column `pdf_file` of type `bytea`; NULLs permitted to simplify development
    pdf_file bytea,
-- Column `created_at` of type `timestamp`; NULLs permitted to simplify development
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
-- Column `hash` of type `character`; NULLs permitted to simplify development
    hash character(64) NOT NULL,
-- Column `appointment_id` of type `uuid`; NULLs permitted to simplify development
    appointment_id uuid NOT NULL
);


-- Column `ALTER` of type `TABLE`; NULLs permitted to simplify development
ALTER TABLE public.medical_records OWNER TO red;

--
-- TOC entry 224 (class 1259 OID 16644)
-- Name: patient_identifiers; Type: TABLE; Schema: public; Owner: red
--

-- Table `public.patient_identifiers`: holds structured data for Patient identifiers
CREATE TABLE public.patient_identifiers (
-- Column `id` of type `integer`; NULLs permitted to simplify development
    id integer NOT NULL,
-- Column `patient_id` of type `uuid`; NULLs permitted to simplify development
    patient_id uuid NOT NULL,
-- Column `identifier_type` of type `public`; NULLs permitted to simplify development
    identifier_type public.identifier_type_enum NOT NULL,
-- Column `identifier_value` of type `character`; NULLs permitted to simplify development
    identifier_value character varying(50) NOT NULL
);


-- Column `ALTER` of type `TABLE`; NULLs permitted to simplify development
ALTER TABLE public.patient_identifiers OWNER TO red;

--
-- TOC entry 225 (class 1259 OID 16647)
-- Name: patient_identifiers_id_seq; Type: SEQUENCE; Schema: public; Owner: red
--

-- Column `CREATE` of type `SEQUENCE`; NULLs permitted to simplify development
CREATE SEQUENCE public.patient_identifiers_id_seq
-- Column `AS` of type `integer`; NULLs permitted to simplify development
    AS integer
-- Column `START` of type `WITH`; NULLs permitted to simplify development
    START WITH 1
-- Column `INCREMENT` of type `BY`; NULLs permitted to simplify development
    INCREMENT BY 1
-- Column `NO` of type `MINVALUE`; NULLs permitted to simplify development
    NO MINVALUE
-- Column `NO` of type `MAXVALUE`; NULLs permitted to simplify development
    NO MAXVALUE
    CACHE 1;


-- Column `ALTER` of type `SEQUENCE`; NULLs permitted to simplify development
ALTER SEQUENCE public.patient_identifiers_id_seq OWNER TO red;

--
-- TOC entry 3558 (class 0 OID 0)
-- Dependencies: 225
-- Name: patient_identifiers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: red
--

-- Column `ALTER` of type `SEQUENCE`; NULLs permitted to simplify development
ALTER SEQUENCE public.patient_identifiers_id_seq OWNED BY public.patient_identifiers.id;


--
-- TOC entry 226 (class 1259 OID 16648)
-- Name: patients; Type: TABLE; Schema: public; Owner: red
--

-- Table `public.patients`: holds structured data for Patients
CREATE TABLE public.patients (
-- Column `id` of type `uuid`; NULLs permitted to simplify development
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
-- Column `first_name` of type `character`; NULLs permitted to simplify development
    first_name character varying(50) NOT NULL,
-- Column `last_name` of type `character`; NULLs permitted to simplify development
    last_name character varying(50) NOT NULL,
-- Column `date_of_birth` of type `date`; NULLs permitted to simplify development
    date_of_birth date NOT NULL,
-- Column `address` of type `text`; NULLs permitted to simplify development
    address text NOT NULL,
-- Column `zip` of type `character`; NULLs permitted to simplify development
    zip character varying(20),
-- Column `phone` of type `character`; NULLs permitted to simplify development
    phone character varying(20) NOT NULL,
-- Column `email` of type `character`; NULLs permitted to simplify development
    email character varying(100) NOT NULL,
-- Column `created_at` of type `timestamp`; NULLs permitted to simplify development
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
-- Column `updated_at` of type `timestamp`; NULLs permitted to simplify development
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
-- Column `external_id` of type `bigint`; NULLs permitted to simplify development
    external_id bigint,
-- Column `gender` of type `character`; NULLs permitted to simplify development
    gender character varying,
-- Column `system_id` of type `uuid`; NULLs permitted to simplify development
    system_id uuid
);


-- Column `ALTER` of type `TABLE`; NULLs permitted to simplify development
ALTER TABLE public.patients OWNER TO red;

--
-- TOC entry 236 (class 1259 OID 16742)
-- Name: pre_anamnesis; Type: TABLE; Schema: public; Owner: red
--

-- Table `public.pre_anamnesis`: holds structured data for Pre anamnesis
CREATE TABLE public.pre_anamnesis (
-- Column `id` of type `integer`; NULLs permitted to simplify development
    id integer NOT NULL,
-- Column `chronic_disease` of type `text`; NULLs permitted to simplify development
    chronic_disease text,
-- Column `smoking` of type `text`; NULLs permitted to simplify development
    smoking text,
-- Column `medicines` of type `text`; NULLs permitted to simplify development
    medicines text,
-- Column `allergies` of type `text`; NULLs permitted to simplify development
    allergies text,
-- Column `existing_illness` of type `text`; NULLs permitted to simplify development
    existing_illness text,
-- Column `alcohol_drug_use` of type `text`; NULLs permitted to simplify development
    alcohol_drug_use text,
-- Column `sleep_diet` of type `text`; NULLs permitted to simplify development
    sleep_diet text,
-- Column `pregnancy_history` of type `text`; NULLs permitted to simplify development
    pregnancy_history text,
-- Column `recent_hospitalization` of type `boolean`; NULLs permitted to simplify development
    recent_hospitalization boolean,
-- Column `created_at` of type `timestamp`; NULLs permitted to simplify development
    created_at timestamp without time zone DEFAULT now(),
-- Column `updated_at` of type `timestamp`; NULLs permitted to simplify development
    updated_at timestamp without time zone DEFAULT now(),
-- Column `patient_id` of type `uuid`; NULLs permitted to simplify development
    patient_id uuid NOT NULL,
-- Column `exams_passwords` of type `jsonb`; NULLs permitted to simplify development
    exams_passwords jsonb,
-- Column `drug_use` of type `text`; NULLs permitted to simplify development
    drug_use text,
-- Column `hospital_history` of type `text`; NULLs permitted to simplify development
    hospital_history text,
-- Column `exam_files` of type `jsonb`; NULLs permitted to simplify development
    exam_files jsonb,
-- Column `recent_exams` of type `text`; NULLs permitted to simplify development
    recent_exams text
);


-- Column `ALTER` of type `TABLE`; NULLs permitted to simplify development
ALTER TABLE public.pre_anamnesis OWNER TO red;

--
-- TOC entry 235 (class 1259 OID 16741)
-- Name: pre_anamnesis_id_seq; Type: SEQUENCE; Schema: public; Owner: red
--

-- Column `CREATE` of type `SEQUENCE`; NULLs permitted to simplify development
CREATE SEQUENCE public.pre_anamnesis_id_seq
-- Column `AS` of type `integer`; NULLs permitted to simplify development
    AS integer
-- Column `START` of type `WITH`; NULLs permitted to simplify development
    START WITH 1
-- Column `INCREMENT` of type `BY`; NULLs permitted to simplify development
    INCREMENT BY 1
-- Column `NO` of type `MINVALUE`; NULLs permitted to simplify development
    NO MINVALUE
-- Column `NO` of type `MAXVALUE`; NULLs permitted to simplify development
    NO MAXVALUE
    CACHE 1;


-- Column `ALTER` of type `SEQUENCE`; NULLs permitted to simplify development
ALTER SEQUENCE public.pre_anamnesis_id_seq OWNER TO red;

--
-- TOC entry 3559 (class 0 OID 0)
-- Dependencies: 235
-- Name: pre_anamnesis_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: red
--

-- Column `ALTER` of type `SEQUENCE`; NULLs permitted to simplify development
ALTER SEQUENCE public.pre_anamnesis_id_seq OWNED BY public.pre_anamnesis.id;


--
-- TOC entry 227 (class 1259 OID 16657)
-- Name: professional_identifiers; Type: TABLE; Schema: public; Owner: red
--

-- Table `public.professional_identifiers`: holds structured data for Professional identifiers
CREATE TABLE public.professional_identifiers (
-- Column `id` of type `integer`; NULLs permitted to simplify development
    id integer NOT NULL,
-- Column `professional_id` of type `uuid`; NULLs permitted to simplify development
    professional_id uuid NOT NULL,
-- Column `identifier_type` of type `public`; NULLs permitted to simplify development
    identifier_type public.professional_identifier_enum NOT NULL,
-- Column `identifier_value` of type `character`; NULLs permitted to simplify development
    identifier_value character varying(50) NOT NULL
);


-- Column `ALTER` of type `TABLE`; NULLs permitted to simplify development
ALTER TABLE public.professional_identifiers OWNER TO red;

--
-- TOC entry 228 (class 1259 OID 16660)
-- Name: professional_identifiers_id_seq; Type: SEQUENCE; Schema: public; Owner: red
--

-- Column `CREATE` of type `SEQUENCE`; NULLs permitted to simplify development
CREATE SEQUENCE public.professional_identifiers_id_seq
-- Column `AS` of type `integer`; NULLs permitted to simplify development
    AS integer
-- Column `START` of type `WITH`; NULLs permitted to simplify development
    START WITH 1
-- Column `INCREMENT` of type `BY`; NULLs permitted to simplify development
    INCREMENT BY 1
-- Column `NO` of type `MINVALUE`; NULLs permitted to simplify development
    NO MINVALUE
-- Column `NO` of type `MAXVALUE`; NULLs permitted to simplify development
    NO MAXVALUE
    CACHE 1;


-- Column `ALTER` of type `SEQUENCE`; NULLs permitted to simplify development
ALTER SEQUENCE public.professional_identifiers_id_seq OWNER TO red;

--
-- TOC entry 3560 (class 0 OID 0)
-- Dependencies: 228
-- Name: professional_identifiers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: red
--

-- Column `ALTER` of type `SEQUENCE`; NULLs permitted to simplify development
ALTER SEQUENCE public.professional_identifiers_id_seq OWNED BY public.professional_identifiers.id;


--
-- TOC entry 229 (class 1259 OID 16661)
-- Name: schedule_dates; Type: TABLE; Schema: public; Owner: red
--

-- Table `public.schedule_dates`: holds structured data for Schedule dates
CREATE TABLE public.schedule_dates (
-- Column `id` of type `integer`; NULLs permitted to simplify development
    id integer NOT NULL,
-- Column `schedule_id` of type `uuid`; NULLs permitted to simplify development
    schedule_id uuid NOT NULL,
-- Column `schedule_date` of type `date`; NULLs permitted to simplify development
    schedule_date date NOT NULL,
-- Column `break_start` of type `time`; NULLs permitted to simplify development
    break_start time without time zone,
-- Column `break_end` of type `time`; NULLs permitted to simplify development
    break_end time without time zone,
-- Column `start_time` of type `time`; NULLs permitted to simplify development
    start_time time without time zone NOT NULL,
-- Column `end_time` of type `time`; NULLs permitted to simplify development
    end_time time without time zone NOT NULL
);


-- Column `ALTER` of type `TABLE`; NULLs permitted to simplify development
ALTER TABLE public.schedule_dates OWNER TO red;

--
-- TOC entry 230 (class 1259 OID 16664)
-- Name: schedule_dates_id_seq; Type: SEQUENCE; Schema: public; Owner: red
--

-- Column `CREATE` of type `SEQUENCE`; NULLs permitted to simplify development
CREATE SEQUENCE public.schedule_dates_id_seq
-- Column `AS` of type `integer`; NULLs permitted to simplify development
    AS integer
-- Column `START` of type `WITH`; NULLs permitted to simplify development
    START WITH 1
-- Column `INCREMENT` of type `BY`; NULLs permitted to simplify development
    INCREMENT BY 1
-- Column `NO` of type `MINVALUE`; NULLs permitted to simplify development
    NO MINVALUE
-- Column `NO` of type `MAXVALUE`; NULLs permitted to simplify development
    NO MAXVALUE
    CACHE 1;


-- Column `ALTER` of type `SEQUENCE`; NULLs permitted to simplify development
ALTER SEQUENCE public.schedule_dates_id_seq OWNER TO red;

--
-- TOC entry 3561 (class 0 OID 0)
-- Dependencies: 230
-- Name: schedule_dates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: red
--

-- Column `ALTER` of type `SEQUENCE`; NULLs permitted to simplify development
ALTER SEQUENCE public.schedule_dates_id_seq OWNED BY public.schedule_dates.id;


--
-- TOC entry 231 (class 1259 OID 16665)
-- Name: schedules; Type: TABLE; Schema: public; Owner: red
--

-- Table `public.schedules`: holds structured data for Schedules
CREATE TABLE public.schedules (
-- Column `id` of type `uuid`; NULLs permitted to simplify development
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
-- Column `doctor_id` of type `uuid`; NULLs permitted to simplify development
    doctor_id uuid NOT NULL,
-- Column `clinic_id` of type `uuid`; NULLs permitted to simplify development
    clinic_id uuid NOT NULL,
-- Column `available_from` of type `time`; NULLs permitted to simplify development
    available_from time without time zone NOT NULL,
-- Column `available_to` of type `time`; NULLs permitted to simplify development
    available_to time without time zone NOT NULL,
-- Column `appointment_interval` of type `integer`; NULLs permitted to simplify development
    appointment_interval integer NOT NULL
);


-- Column `ALTER` of type `TABLE`; NULLs permitted to simplify development
ALTER TABLE public.schedules OWNER TO red;

--
-- TOC entry 232 (class 1259 OID 16669)
-- Name: test_table; Type: TABLE; Schema: public; Owner: red
--

-- Table `public.test_table`: holds structured data for Test table
CREATE TABLE public.test_table (
-- Column `id` of type `integer`; NULLs permitted to simplify development
    id integer NOT NULL,
-- Column `name` of type `text`; NULLs permitted to simplify development
    name text NOT NULL
);


-- Column `ALTER` of type `TABLE`; NULLs permitted to simplify development
ALTER TABLE public.test_table OWNER TO red;

--
-- TOC entry 233 (class 1259 OID 16674)
-- Name: test_table_id_seq; Type: SEQUENCE; Schema: public; Owner: red
--

-- Column `CREATE` of type `SEQUENCE`; NULLs permitted to simplify development
CREATE SEQUENCE public.test_table_id_seq
-- Column `AS` of type `integer`; NULLs permitted to simplify development
    AS integer
-- Column `START` of type `WITH`; NULLs permitted to simplify development
    START WITH 1
-- Column `INCREMENT` of type `BY`; NULLs permitted to simplify development
    INCREMENT BY 1
-- Column `NO` of type `MINVALUE`; NULLs permitted to simplify development
    NO MINVALUE
-- Column `NO` of type `MAXVALUE`; NULLs permitted to simplify development
    NO MAXVALUE
    CACHE 1;


-- Column `ALTER` of type `SEQUENCE`; NULLs permitted to simplify development
ALTER SEQUENCE public.test_table_id_seq OWNER TO red;

--
-- TOC entry 3562 (class 0 OID 0)
-- Dependencies: 233
-- Name: test_table_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: red
--

-- Column `ALTER` of type `SEQUENCE`; NULLs permitted to simplify development
ALTER SEQUENCE public.test_table_id_seq OWNED BY public.test_table.id;


--
-- TOC entry 234 (class 1259 OID 16675)
-- Name: users; Type: TABLE; Schema: public; Owner: red
--

-- Table `public.users`: holds structured data for Users
CREATE TABLE public.users (
-- Column `id` of type `uuid`; NULLs permitted to simplify development
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
-- Column `username` of type `character`; NULLs permitted to simplify development
    username character varying(50) NOT NULL,
-- Column `name` of type `character`; NULLs permitted to simplify development
    name character varying(100) NOT NULL,
-- Column `email` of type `character`; NULLs permitted to simplify development
    email character varying(255) NOT NULL,
-- Column `phone` of type `character`; NULLs permitted to simplify development
    phone character varying(20),
-- Column `password_hash` of type `character`; NULLs permitted to simplify development
    password_hash character varying(255) NOT NULL,
-- Column `status` of type `public`; NULLs permitted to simplify development
    status public.status_enum DEFAULT 'active'::public.status_enum NOT NULL,
-- Column `last_login` of type `timestamp`; NULLs permitted to simplify development
    last_login timestamp without time zone,
-- Column `created_at` of type `timestamp`; NULLs permitted to simplify development
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
-- Column `updated_at` of type `timestamp`; NULLs permitted to simplify development
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
-- Column `healthcare_professional_id` of type `uuid`; NULLs permitted to simplify development
    healthcare_professional_id uuid,
-- Column `front_desk_user_id` of type `uuid`; NULLs permitted to simplify development
    front_desk_user_id uuid,
-- Column `roles` of type `jsonb`; NULLs permitted to simplify development
    roles jsonb NOT NULL,
-- Column `recovery_token` of type `character`; NULLs permitted to simplify development
    recovery_token character varying(255),
-- Column `system_id` of type `uuid`; NULLs permitted to simplify development
    system_id uuid
);


-- Column `ALTER` of type `TABLE`; NULLs permitted to simplify development
ALTER TABLE public.users OWNER TO red;

--
-- TOC entry 3309 (class 2604 OID 16689)
-- Name: employment_link id; Type: DEFAULT; Schema: public; Owner: red
--

-- Column `ALTER` of type `TABLE`; NULLs permitted to simplify development
ALTER TABLE ONLY public.employment_link ALTER COLUMN id SET DEFAULT nextval('public.employment_link_id_seq'::regclass);


--
-- TOC entry 3315 (class 2604 OID 16690)
-- Name: patient_identifiers id; Type: DEFAULT; Schema: public; Owner: red
--

-- Column `ALTER` of type `TABLE`; NULLs permitted to simplify development
ALTER TABLE ONLY public.patient_identifiers ALTER COLUMN id SET DEFAULT nextval('public.patient_identifiers_id_seq'::regclass);


--
-- TOC entry 3327 (class 2604 OID 16745)
-- Name: pre_anamnesis id; Type: DEFAULT; Schema: public; Owner: red
--

-- Column `ALTER` of type `TABLE`; NULLs permitted to simplify development
ALTER TABLE ONLY public.pre_anamnesis ALTER COLUMN id SET DEFAULT nextval('public.pre_anamnesis_id_seq'::regclass);


--
-- TOC entry 3319 (class 2604 OID 16691)
-- Name: professional_identifiers id; Type: DEFAULT; Schema: public; Owner: red
--

-- Column `ALTER` of type `TABLE`; NULLs permitted to simplify development
ALTER TABLE ONLY public.professional_identifiers ALTER COLUMN id SET DEFAULT nextval('public.professional_identifiers_id_seq'::regclass);


--
-- TOC entry 3320 (class 2604 OID 16692)
-- Name: schedule_dates id; Type: DEFAULT; Schema: public; Owner: red
--

-- Column `ALTER` of type `TABLE`; NULLs permitted to simplify development
ALTER TABLE ONLY public.schedule_dates ALTER COLUMN id SET DEFAULT nextval('public.schedule_dates_id_seq'::regclass);


--
-- TOC entry 3322 (class 2604 OID 16693)
-- Name: test_table id; Type: DEFAULT; Schema: public; Owner: red
--

-- Column `ALTER` of type `TABLE`; NULLs permitted to simplify development
ALTER TABLE ONLY public.test_table ALTER COLUMN id SET DEFAULT nextval('public.test_table_id_seq'::regclass);


--
-- TOC entry 3550 (class 0 OID 16813)
-- Dependencies: 238
-- Data for Name: api_keys; Type: TABLE DATA; Schema: public; Owner: red
--

-- Column `ALTER` of type `TABLE`; NULLs permitted to simplify development
ALTER TABLE ONLY public.api_keys
-- Column `ADD` of type `CONSTRAINT`; NULLs permitted to simplify development
    ADD CONSTRAINT api_keys_pkey PRIMARY KEY (id);


--
-- TOC entry 3372 (class 2606 OID 16822)
-- Name: api_keys api_keys_token_key; Type: CONSTRAINT; Schema: public; Owner: red
--

-- Column `ALTER` of type `TABLE`; NULLs permitted to simplify development
ALTER TABLE ONLY public.api_keys
-- Column `ADD` of type `CONSTRAINT`; NULLs permitted to simplify development
    ADD CONSTRAINT api_keys_token_key UNIQUE (token);


--
-- TOC entry 3334 (class 2606 OID 16695)
-- Name: appointments appointments_pkey; Type: CONSTRAINT; Schema: public; Owner: red
--

-- Column `ALTER` of type `TABLE`; NULLs permitted to simplify development
ALTER TABLE ONLY public.appointments
-- Column `ADD` of type `CONSTRAINT`; NULLs permitted to simplify development
    ADD CONSTRAINT appointments_pkey PRIMARY KEY (id);


--
-- TOC entry 3337 (class 2606 OID 16697)
-- Name: care_link care_link_pkey; Type: CONSTRAINT; Schema: public; Owner: red
--

-- Column `ALTER` of type `TABLE`; NULLs permitted to simplify development
ALTER TABLE ONLY public.care_link
-- Column `ADD` of type `CONSTRAINT`; NULLs permitted to simplify development
    ADD CONSTRAINT care_link_pkey PRIMARY KEY (id);


--
-- TOC entry 3342 (class 2606 OID 16699)
-- Name: clinics clinics_pkey; Type: CONSTRAINT; Schema: public; Owner: red
--

-- Column `ALTER` of type `TABLE`; NULLs permitted to simplify development
ALTER TABLE ONLY public.clinics
-- Column `ADD` of type `CONSTRAINT`; NULLs permitted to simplify development
    ADD CONSTRAINT clinics_pkey PRIMARY KEY (id);


--
-- TOC entry 3346 (class 2606 OID 16701)
-- Name: employment_link employment_link_pkey; Type: CONSTRAINT; Schema: public; Owner: red
--

-- Column `ALTER` of type `TABLE`; NULLs permitted to simplify development
ALTER TABLE ONLY public.employment_link
-- Column `ADD` of type `CONSTRAINT`; NULLs permitted to simplify development
    ADD CONSTRAINT employment_link_pkey PRIMARY KEY (id);


--
-- TOC entry 3368 (class 2606 OID 16811)
-- Name: external_systems external_systems_pkey; Type: CONSTRAINT; Schema: public; Owner: red
--

-- Column `ALTER` of type `TABLE`; NULLs permitted to simplify development
ALTER TABLE ONLY public.external_systems
-- Column `ADD` of type `CONSTRAINT`; NULLs permitted to simplify development
    ADD CONSTRAINT external_systems_pkey PRIMARY KEY (id);


--
-- TOC entry 3348 (class 2606 OID 16703)
-- Name: front_desk_users front_desk_users_pkey; Type: CONSTRAINT; Schema: public; Owner: red
--

-- Column `ALTER` of type `TABLE`; NULLs permitted to simplify development
ALTER TABLE ONLY public.front_desk_users
-- Column `ADD` of type `CONSTRAINT`; NULLs permitted to simplify development
    ADD CONSTRAINT front_desk_users_pkey PRIMARY KEY (id);


--
-- TOC entry 3350 (class 2606 OID 16705)
-- Name: healthcare_professionals healthcare_professionals_pkey; Type: CONSTRAINT; Schema: public; Owner: red
--

-- Column `ALTER` of type `TABLE`; NULLs permitted to simplify development
ALTER TABLE ONLY public.healthcare_professionals
-- Column `ADD` of type `CONSTRAINT`; NULLs permitted to simplify development
    ADD CONSTRAINT healthcare_professionals_pkey PRIMARY KEY (id);


--
-- TOC entry 3354 (class 2606 OID 16707)
-- Name: patient_identifiers patient_identifiers_pkey; Type: CONSTRAINT; Schema: public; Owner: red
--

-- Column `ALTER` of type `TABLE`; NULLs permitted to simplify development
ALTER TABLE ONLY public.patient_identifiers
-- Column `ADD` of type `CONSTRAINT`; NULLs permitted to simplify development
    ADD CONSTRAINT patient_identifiers_pkey PRIMARY KEY (id);


--
-- TOC entry 3356 (class 2606 OID 16725)
-- Name: patients patients_pkey; Type: CONSTRAINT; Schema: public; Owner: red
--

-- Column `ALTER` of type `TABLE`; NULLs permitted to simplify development
ALTER TABLE ONLY public.patients
-- Column `ADD` of type `CONSTRAINT`; NULLs permitted to simplify development
    ADD CONSTRAINT patients_pkey PRIMARY KEY (id);


--
-- TOC entry 3366 (class 2606 OID 16751)
-- Name: pre_anamnesis pre_anamnesis_pkey; Type: CONSTRAINT; Schema: public; Owner: red
--

-- Column `ALTER` of type `TABLE`; NULLs permitted to simplify development
ALTER TABLE ONLY public.pre_anamnesis
-- Column `ADD` of type `CONSTRAINT`; NULLs permitted to simplify development
    ADD CONSTRAINT pre_anamnesis_pkey PRIMARY KEY (id);


--
-- TOC entry 3360 (class 2606 OID 16709)
-- Name: schedule_dates schedule_dates_pkey; Type: CONSTRAINT; Schema: public; Owner: red
--

-- Column `ALTER` of type `TABLE`; NULLs permitted to simplify development
ALTER TABLE ONLY public.schedule_dates
-- Column `ADD` of type `CONSTRAINT`; NULLs permitted to simplify development
    ADD CONSTRAINT schedule_dates_pkey PRIMARY KEY (id);


--
-- TOC entry 3362 (class 2606 OID 16711)
-- Name: schedules schedules_pkey; Type: CONSTRAINT; Schema: public; Owner: red
--

-- Column `ALTER` of type `TABLE`; NULLs permitted to simplify development
ALTER TABLE ONLY public.schedules
-- Column `ADD` of type `CONSTRAINT`; NULLs permitted to simplify development
    ADD CONSTRAINT schedules_pkey PRIMARY KEY (id);


--
-- TOC entry 3340 (class 2606 OID 16772)
-- Name: care_link unique_care_link; Type: CONSTRAINT; Schema: public; Owner: red
--

-- Column `ALTER` of type `TABLE`; NULLs permitted to simplify development
ALTER TABLE ONLY public.care_link
-- Column `ADD` of type `CONSTRAINT`; NULLs permitted to simplify development
    ADD CONSTRAINT unique_care_link UNIQUE (clinic_id, patient_id, doctor_id);


--
-- TOC entry 3352 (class 2606 OID 16861)
-- Name: healthcare_professionals unique_doctor_external_system; Type: CONSTRAINT; Schema: public; Owner: red
--

-- Column `ALTER` of type `TABLE`; NULLs permitted to simplify development
ALTER TABLE ONLY public.healthcare_professionals
-- Column `ADD` of type `CONSTRAINT`; NULLs permitted to simplify development
    ADD CONSTRAINT unique_doctor_external_system UNIQUE (external_id, system_id);


--
-- TOC entry 3358 (class 2606 OID 16859)
-- Name: patients unique_patient_external_system; Type: CONSTRAINT; Schema: public; Owner: red
--

-- Column `ALTER` of type `TABLE`; NULLs permitted to simplify development
ALTER TABLE ONLY public.patients
-- Column `ADD` of type `CONSTRAINT`; NULLs permitted to simplify development
    ADD CONSTRAINT unique_patient_external_system UNIQUE (external_id, system_id);


--
-- TOC entry 3344 (class 2606 OID 16875)
-- Name: clinics unique_system_external; Type: CONSTRAINT; Schema: public; Owner: red
--

-- Column `ALTER` of type `TABLE`; NULLs permitted to simplify development
ALTER TABLE ONLY public.clinics
-- Column `ADD` of type `CONSTRAINT`; NULLs permitted to simplify development
    ADD CONSTRAINT unique_system_external UNIQUE (system_id, external_id);


--
-- TOC entry 3364 (class 2606 OID 16713)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: red
--

-- Column `ALTER` of type `TABLE`; NULLs permitted to simplify development
ALTER TABLE ONLY public.users
-- Column `ADD` of type `CONSTRAINT`; NULLs permitted to simplify development
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- TOC entry 3335 (class 1259 OID 16785)
-- Name: idx_appointments_date; Type: INDEX; Schema: public; Owner: red
--

-- Column `CREATE` of type `INDEX`; NULLs permitted to simplify development
CREATE INDEX idx_appointments_date ON public.appointments USING btree (date);


--
-- TOC entry 3338 (class 1259 OID 16784)
-- Name: idx_care_link_clinic_patient_doctor; Type: INDEX; Schema: public; Owner: red
--

-- Column `CREATE` of type `UNIQUE`; NULLs permitted to simplify development
CREATE UNIQUE INDEX idx_care_link_clinic_patient_doctor ON public.care_link USING btree (clinic_id, patient_id, doctor_id);


--
-- TOC entry 3384 (class 2606 OID 16823)
-- Name: api_keys api_keys_system_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: red
--

-- Column `ALTER` of type `TABLE`; NULLs permitted to simplify development
ALTER TABLE ONLY public.api_keys
-- Column `ADD` of type `CONSTRAINT`; NULLs permitted to simplify development
    ADD CONSTRAINT api_keys_system_id_fkey FOREIGN KEY (system_id) REFERENCES public.external_systems(id);


--
-- TOC entry 3377 (class 2606 OID 16843)
-- Name: clinics clinics_system_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: red
--

-- Column `ALTER` of type `TABLE`; NULLs permitted to simplify development
ALTER TABLE ONLY public.clinics
-- Column `ADD` of type `CONSTRAINT`; NULLs permitted to simplify development
    ADD CONSTRAINT clinics_system_id_fkey FOREIGN KEY (system_id) REFERENCES public.external_systems(id);


--
-- TOC entry 3374 (class 2606 OID 16714)
-- Name: care_link fk_care_link_clinic; Type: FK CONSTRAINT; Schema: public; Owner: red
--

-- Column `ALTER` of type `TABLE`; NULLs permitted to simplify development
ALTER TABLE ONLY public.care_link
-- Column `ADD` of type `CONSTRAINT`; NULLs permitted to simplify development
    ADD CONSTRAINT fk_care_link_clinic FOREIGN KEY (clinic_id) REFERENCES public.clinics(id);


--
-- TOC entry 3375 (class 2606 OID 16719)
-- Name: care_link fk_care_link_doctor; Type: FK CONSTRAINT; Schema: public; Owner: red
--

-- Column `ALTER` of type `TABLE`; NULLs permitted to simplify development
ALTER TABLE ONLY public.care_link
-- Column `ADD` of type `CONSTRAINT`; NULLs permitted to simplify development
    ADD CONSTRAINT fk_care_link_doctor FOREIGN KEY (doctor_id) REFERENCES public.healthcare_professionals(id);


--
-- TOC entry 3376 (class 2606 OID 16726)
-- Name: care_link fk_care_link_patient; Type: FK CONSTRAINT; Schema: public; Owner: red
--

-- Column `ALTER` of type `TABLE`; NULLs permitted to simplify development
ALTER TABLE ONLY public.care_link
-- Column `ADD` of type `CONSTRAINT`; NULLs permitted to simplify development
    ADD CONSTRAINT fk_care_link_patient FOREIGN KEY (patient_id) REFERENCES public.patients(id);


--
-- TOC entry 3373 (class 2606 OID 16760)
-- Name: appointments fk_clinic; Type: FK CONSTRAINT; Schema: public; Owner: red
--

-- Column `ALTER` of type `TABLE`; NULLs permitted to simplify development
ALTER TABLE ONLY public.appointments
-- Column `ADD` of type `CONSTRAINT`; NULLs permitted to simplify development
    ADD CONSTRAINT fk_clinic FOREIGN KEY (clinic_id) REFERENCES public.clinics(id) ON DELETE CASCADE;


--
-- TOC entry 3378 (class 2606 OID 16731)
-- Name: employment_link fk_employment_link_clinic; Type: FK CONSTRAINT; Schema: public; Owner: red
--

-- Column `ALTER` of type `TABLE`; NULLs permitted to simplify development
ALTER TABLE ONLY public.employment_link
-- Column `ADD` of type `CONSTRAINT`; NULLs permitted to simplify development
    ADD CONSTRAINT fk_employment_link_clinic FOREIGN KEY (clinic_id) REFERENCES public.clinics(id);


--
-- TOC entry 3379 (class 2606 OID 16736)
-- Name: employment_link fk_employment_link_doctor; Type: FK CONSTRAINT; Schema: public; Owner: red
--

-- Column `ALTER` of type `TABLE`; NULLs permitted to simplify development
ALTER TABLE ONLY public.employment_link
-- Column `ADD` of type `CONSTRAINT`; NULLs permitted to simplify development
    ADD CONSTRAINT fk_employment_link_doctor FOREIGN KEY (doctor_id) REFERENCES public.healthcare_professionals(id);


--
-- TOC entry 3383 (class 2606 OID 16753)
-- Name: pre_anamnesis fk_patient_id; Type: FK CONSTRAINT; Schema: public; Owner: red
--

-- Column `ALTER` of type `TABLE`; NULLs permitted to simplify development
ALTER TABLE ONLY public.pre_anamnesis
-- Column `ADD` of type `CONSTRAINT`; NULLs permitted to simplify development
    ADD CONSTRAINT fk_patient_id FOREIGN KEY (patient_id) REFERENCES public.patients(id);


--
-- TOC entry 3380 (class 2606 OID 16838)
-- Name: healthcare_professionals healthcare_professionals_system_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: red
--

-- Column `ALTER` of type `TABLE`; NULLs permitted to simplify development
ALTER TABLE ONLY public.healthcare_professionals
-- Column `ADD` of type `CONSTRAINT`; NULLs permitted to simplify development
    ADD CONSTRAINT healthcare_professionals_system_id_fkey FOREIGN KEY (system_id) REFERENCES public.external_systems(id);


--
-- TOC entry 3381 (class 2606 OID 16853)
-- Name: patients patients_system_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: red
--

-- Column `ALTER` of type `TABLE`; NULLs permitted to simplify development
ALTER TABLE ONLY public.patients
-- Column `ADD` of type `CONSTRAINT`; NULLs permitted to simplify development
    ADD CONSTRAINT patients_system_id_fkey FOREIGN KEY (system_id) REFERENCES public.external_systems(id);


--
-- TOC entry 3382 (class 2606 OID 16862)
-- Name: users users_system_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: red
--

-- Column `ALTER` of type `TABLE`; NULLs permitted to simplify development
ALTER TABLE ONLY public.users
-- Column `ADD` of type `CONSTRAINT`; NULLs permitted to simplify development
    ADD CONSTRAINT users_system_id_fkey FOREIGN KEY (system_id) REFERENCES public.external_systems(id);


--
-- TOC entry 3556 (class 0 OID 0)
-- Dependencies: 6
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: red
--

-- Column `REVOKE` of type `USAGE`; NULLs permitted to simplify development
REVOKE USAGE ON SCHEMA public FROM PUBLIC;


-- Completed on 2025-07-13 18:31:01 CEST

--
-- PostgreSQL database dump complete
--
