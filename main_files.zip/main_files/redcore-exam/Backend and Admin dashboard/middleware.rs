use actix_web::{dev::ServiceRequest, Error, HttpMessage};
use actix_web_httpauth::extractors::bearer::BearerAuth;
use sqlx::PgPool;
use tracing::{error, info, instrument, warn};

use crate::auth::api::validate_api_key;
use crate::auth::jwt::{validate_patient_token, validate_token};
use crate::models::patient::PatientClaim;
use crate::models::user::Claim;

/// Authentication type enum to distinguish between different auth methods
///
/// CRITICAL: This enum is stored in request extensions and used by handlers
/// to determine the type of authenticated entity and extract claims/data.
///
/// The middleware inserts the appropriate variant based on the token type,
/// and handlers pattern match on this to extract the right data.
#[derive(Debug, Clone)]
pub enum AuthType {
    AdminUser(Claim),      // Standard JWT for admin users with roles and permissions
    Patient(PatientClaim), // JWT for patients with patient-specific data
    ApiKey(crate::auth::api::ApiKey), // API key for external system integrations
}

/// JWT token authentication middleware for admin users and patients
///
/// This validator tries admin token first, then patient token if admin fails.
/// It stores the result in request extensions as AuthType for handlers to use.
///
/// IMPORTANT: This is different from api_key_validator - they handle different auth types!
#[instrument(skip(req, credentials))]
pub async fn jwt_validator(
    req: ServiceRequest,
    credentials: BearerAuth,
) -> Result<ServiceRequest, (Error, ServiceRequest)> {
    if credentials.token().is_empty() {
        warn!("🚨 JWT Authentication failed: Missing token");
        return Err((actix_web::error::ErrorUnauthorized("Missing token"), req));
    }

    // Try to validate as admin user token first
    // This allows admin users to access patient endpoints if needed
    match validate_token(credentials.token()) {
        Ok(claims) => {
            info!(
                event = "jwt_admin_authentication_successful",
                user_id = %claims.sub,
                roles = ?claims.roles,
                "✅ Admin JWT Authentication successful"
            );
            // Store admin claims in request extensions for handlers to access
            req.extensions_mut().insert(AuthType::AdminUser(claims));
            return Ok(req);
        }
        Err(_) => {
            // If admin token validation fails, try patient token
            // This allows the same endpoint to serve both admin and patient requests
            match validate_patient_token(credentials.token()) {
                Ok(claims) => {
                    info!(
                        event = "jwt_patient_authentication_successful",
                        patient_id = %claims.sub,
                        "✅ Patient JWT Authentication successful"
                    );
                    req.extensions_mut().insert(AuthType::Patient(claims));
                    return Ok(req);
                }
                Err(err) => {
                    error!(
                        event = "jwt_authentication_failed",
                        error = %err,
                        "🚨 JWT Authentication failed for both admin and patient tokens"
                    );
                    return Err((
                        actix_web::error::ErrorUnauthorized("Invalid or missing JWT token"),
                        req,
                    ));
                }
            }
        }
    }
}

/// API key authentication middleware for external system integrations
///
/// This is completely separate from JWT auth and only validates API keys.
/// Used for /api routes where external systems need to access our endpoints.
///
/// CRITICAL: API keys are validated against the database and include permissions.
#[instrument(skip(req, credentials))]
pub async fn api_key_validator(
    req: ServiceRequest,
    credentials: BearerAuth,
) -> Result<ServiceRequest, (Error, ServiceRequest)> {
    let token = credentials.token();
    info!(
        "🔍 API Key validation starting for token: {}...",
        &token[..std::cmp::min(token.len(), 10)]
    );

    if token.is_empty() {
        warn!("🚨 API Key Authentication failed: Missing token");
        return Err((actix_web::error::ErrorUnauthorized("Missing API key"), req));
    }

    // Get database pool from app data - needed for API key validation
    let pool = req.app_data::<actix_web::web::Data<PgPool>>();

    match pool {
        Some(pool) => {
            info!("🔍 Database pool found, validating API key against database");
            // Validate API key against database (includes SHA-256 hash verification)
            match validate_api_key(pool.get_ref(), token).await {
                Ok(api_key) => {
                    info!(
                        event = "api_key_authentication_successful",
                        system_id = %api_key.system_id,
                        permissions = ?api_key.permissions,
                        "✅ API Key Authentication successful"
                    );
                    // Store API key data in request extensions
                    req.extensions_mut().insert(AuthType::ApiKey(api_key));
                    Ok(req)
                }
                Err(err) => {
                    error!(
                        event = "api_key_authentication_failed",
                        error = %err,
                        token_prefix = &token[..std::cmp::min(token.len(), 10)],
                        "🚨 API Key Authentication failed"
                    );
                    Err((actix_web::error::ErrorUnauthorized("Invalid API key"), req))
                }
            }
        }
        None => {
            error!("🚨 Database pool not found in app data");
            Err((
                actix_web::error::ErrorInternalServerError("Database connection error"),
                req,
            ))
        }
    }
}

/// Legacy validator for backward compatibility - will be deprecated
#[instrument(skip(req, credentials))]
pub async fn legacy_validator(
    req: ServiceRequest,
    credentials: BearerAuth,
) -> Result<ServiceRequest, (Error, ServiceRequest)> {
    // This maintains the old behavior for routes that haven't been migrated yet
    jwt_validator(req, credentials).await
}

/// Utility function to check if request has authentication information
#[allow(dead_code)]
pub fn has_auth_info(req: &actix_web::HttpRequest) -> bool {
    req.extensions().get::<AuthType>().is_some()
}

/// Extract admin user ID from request if authenticated as admin
#[allow(dead_code)]
pub fn get_admin_user_id(req: &actix_web::HttpRequest) -> Option<uuid::Uuid> {
    match req.extensions().get::<AuthType>() {
        Some(AuthType::AdminUser(claim)) => Some(claim.sub),
        _ => None,
    }
}

/// Extract patient ID from request if authenticated as patient
#[allow(dead_code)]
pub fn get_patient_id(req: &actix_web::HttpRequest) -> Option<uuid::Uuid> {
    match req.extensions().get::<AuthType>() {
        Some(AuthType::Patient(claim)) => Some(claim.sub),
        _ => None,
    }
}

/// Extract system ID from API key if authenticated as external system
pub fn get_system_id(req: &actix_web::HttpRequest) -> Option<uuid::Uuid> {
    match req.extensions().get::<AuthType>() {
        Some(AuthType::ApiKey(key)) => Some(key.system_id),
        _ => None,
    }
}

/// Utility function to check if request has admin privileges
#[allow(dead_code)]
pub fn is_admin_request(req: &actix_web::HttpRequest) -> bool {
    matches!(
        req.extensions().get::<AuthType>(),
        Some(AuthType::AdminUser(_))
    )
}

/// Utility function to check if request is from a patient
#[allow(dead_code)]
pub fn is_patient_request(req: &actix_web::HttpRequest) -> bool {
    matches!(
        req.extensions().get::<AuthType>(),
        Some(AuthType::Patient(_))
    )
}

/// Utility function to check if request is from external system
pub fn is_external_system_request(req: &actix_web::HttpRequest) -> bool {
    matches!(
        req.extensions().get::<AuthType>(),
        Some(AuthType::ApiKey(_))
    )
}
