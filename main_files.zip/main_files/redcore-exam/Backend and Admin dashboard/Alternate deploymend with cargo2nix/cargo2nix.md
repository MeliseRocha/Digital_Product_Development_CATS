# Cargo2Nix Implementation

## Implementation Steps

### 1. Generate Cargo.nix

```bash
# Get cargo2nix development environment
nix develop github:cargo2nix/cargo2nix#bootstrap

nix run github:cargo2nix/cargo2nix

# Commit the generated file (required!)
git add Cargo.nix
git commit -m "Add Cargo.nix for reproducible builds"
```

### 2. Create flake.nix

```nix
{
  inputs = {
    rust-overlay.url = "github:oxalica/rust-overlay/stable";
    cargo2nix = {
      url = "github:cargo2nix/cargo2nix/release-0.12";
      inputs.rust-overlay.follows = "rust-overlay";
    };
    flake-utils.follows = "cargo2nix/flake-utils";
    nixpkgs.follows = "cargo2nix/nixpkgs";
  };

  outputs = inputs: with inputs;
    flake-utils.lib.eachDefaultSystem (system:
      let
        pkgs = import nixpkgs {
          inherit system;
          overlays = [cargo2nix.overlays.default];
        };

        rustPkgs = pkgs.rustBuilder.makePackageSet {
          rustVersion = "1.87.0";
          packageFun = import ./Cargo.nix;
          packageOverrides = pkgs: pkgs.rustBuilder.overrides.all ++ [
            (pkgs.rustBuilder.rustLib.makeOverride {
              name = "redcore";
              overrideAttrs = drv: {
                SQLX_OFFLINE = "true";
              };
            })
          ];
        };

      in rec {
        packages = {
          redcore = (rustPkgs.workspace.redcore {});
          default = packages.redcore;
        };
      }
    );
}
```

### 3. Handle SQLx Offline Compilation

SQLx requires database access during compilation. For Nix builds:

1. **Generate SQLx cache**: Run locally with database to generate `.sqlx/` directory
2. **Commit cache**: `git add .sqlx/`
3. **Set SQLX_OFFLINE=true**: Added in package overrides above

### 4. Configure Nix Experimental Features

```bash
mkdir -p ~/.config/nix
echo "experimental-features = nix-command flakes" >> ~/.config/nix/nix.conf
```

### 5. Build and Deploy

```bash
# Build
nix build

# Binary location
./result/bin/redcore

# Deploy to Debian systems
scp result/bin/redcore user@server:/opt/redcore/
scp .env user@server:/opt/redcore/
scp -r src/frontend user@server:/opt/redcore/
```

## Key Files

- **Cargo.nix**: Generated dependency specifications (version controlled)
- **flake.nix**: Nix build configuration
- **flake.lock**: Pinned input versions (auto-generated)
- **.sqlx/**: SQLx query cache (version controlled)

## CI/CD Note

**Not implementing for now** because:
- Render doesn't provide SSH access in free tier
- Render is designed for container deployments
- Our static binary approach suits traditional VPS deployment better
- For some reason I wasn't able to discover the compiling inside the container is not multithreaded and takes ages.

## Troubleshooting

### SQLx compilation errors
Ensure `.sqlx/` directory is committed and `SQLX_OFFLINE=true` is set

### Rust version not found
Include rust-overlay in flake inputs

### Updating Dependencies
```bash
cargo update
nix develop github:cargo2nix/cargo2nix#bootstrap
cargo2nix
git add Cargo.nix Cargo.lock
git commit -m "Update dependencies"
```
