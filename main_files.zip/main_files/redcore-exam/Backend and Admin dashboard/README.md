# RedCore - Patient Intake API & Chatbot Backend

A healthcare backend system built with Rust and Actix-web, providing secure APIs for patient intake management and chatbot integration ### 🔑 **EHR System Integration (API Key Authentication)**

**Primary Endpoint:**
- `POST /api/appointments/make` - **PRIMARY ENDPOINT** - EHR systems call this to start patient intake workflow

**Data Access:**
- `GET /api/patients/{id}/pre-anamnesis` - Retrieve patient pre-anamnesis data for EHR systems
- `GET /api/files/{filename}` - Download appointment filesternal Health Records (EHR) systems.

## 🏥 Overview

**IMPORTANT: The entire patient intake workflow starts when a patient schedules an appointment in an external EHR system.**

### Patient Intake Workflow

```mermaid
sequenceDiagram
    participant P as Patient
    participant EHR as EHR System
    participant RC as RedCore API
    participant DB as Database
    participant Email as Email Service
    participant Frontend as Patient Portal

    Note over P,Frontend: Patient Intake Workflow
    
    P->>EHR: 1. Schedules appointment
    EHR->>RC: 2. POST /appointments/make<br/>(API Key Auth)
    RC->>DB: 3. Create patient & appointment
    RC->>Email: 4. Send email with JWT token
    Email->>P: 5. Email with secure link
    
    P->>Frontend: 6. Click link with JWT token
    Frontend->>RC: 7. Access intake form<br/>(JWT Auth)
    P->>Frontend: 8. Complete pre-anamnesis
    Frontend->>RC: 9. Submit form data<br/>(JWT Auth)
    RC->>DB: 10. Store pre-anamnesis
    RC->>EHR: 11. API callback with data<br/>(API integration)


```

**Patient Intake Flowchart:**

```mermaid
---
config:
  theme: default
  look: handDrawn
---
flowchart LR
    A["👤 Patient schedules<br/>appointment in EHR"] --> B["🏥 EHR System"]
    B --> C["🔑 POST /appointments/make<br/>API Key Auth"]
    C --> D["⚙️ RedCore creates<br/>patient/doctor/clinic"]
    D --> E["📧 Send HTML email<br/>with JWT token"]
    E --> F["🖥️ Patient accesses<br/>chatbot frontend"]
    F --> G["📝 Complete 13-field<br/>pre-anamnesis form"]
    G --> H["💾 Submit & store<br/>form data"]
    H --> I["🔄 EHR retrieves data<br/>GET /patients/ID/pre-anamnesis"]
    I --> B
    style A fill:#e1f5fe
    style C fill:#fff3e0
    style E fill:#f3e5f5
    style G fill:#e8f5e8
    style I fill:#fff3e0

```

RedCore serves as the backend infrastructure for this patient intake system, featuring:

- **EHR Integration**: API key-based access for external health record systems via `/appointments/make` endpoint
- **Pre-Anamnesis System**: Comprehensive medical history collection and storage
- **Patient Intake Workflow**: Automated patient, doctor, and clinic record creation from EHR data
- **Patient Frontend**: Chatbot interface for form completion
- **Admin Frontend**: Dynamic dashboard for patient viewing and API testing
- **Secure Authentication**: JWT tokens for patients, API keys for EHR systems, admin login with Argon2 hashing
- **Email Services**: Automated HTML email notifications with secure JWT tokens for patient access
- **File Management**: Document upload and download for appointment-related files

## 🚀 Features

### Core Functionality

- ✅ **Appointment-Triggered Patient Intake** via EHR integration
- ✅ **Pre-Anamnesis Data Collection**
- ✅ **Multi-tier Authentication**
- ✅ **Email Integration** (HTML templates with SMTP)
- ✅ **File Upload/Download System** for appointment documents
- ✅ **Admin Dashboard** (patient database viewing and API testing interface)
- ✅ **Password Recovery System** with secure JWT tokens
- ✅ **CORS Support**
- ✅ **Comprehensive Error Handling** and request validation
- ✅ **Request Tracing & Logging** with structured logging

### Security Features

- 🔐 **Argon2 Password Hashing** for admin users
- 🔑 **JWT Token Authentication** for patients and admins
- 🔓 **API Key Authentication** for EHR systems
- 🛡️ **Role-based Authorization** 
- 🌐 **CORS Protection**
- 📝 **Request Validation**

## 🛠️ Tech Stack

- **Framework**: [Actix-web 4.0](https://actix.rs/) with [Tokio](https://tokio.rs/) async runtime
- **Database**: PostgreSQL with [SQLx](https://github.com/launchbadge/sqlx)
- **Authentication**: [jsonwebtoken](https://github.com/Keats/jsonwebtoken) + [Argon2](https://github.com/RustCrypto/password-hashes/tree/master/argon2)
- **Email**: [Lettre](https://lettre.rs/) with HTML templates
- **Validation**: [Validator](https://github.com/Keats/validator) + [Serde](https://serde.rs/)
- **Observability**: [tracing](https://github.com/tokio-rs/tracing) + [tracing-actix-web](https://github.com/LukeMathWalker/tracing-actix-web)
- **Deployment**: **Multi-stage Docker build** with **minimal scratch-based container**

## 📦 Installation

### Prerequisites

- **Rust** 1.70+ (with Cargo)
- **PostgreSQL** 16+
- **Docker** (for development database)

### Quick Start

1. **Clone the repository**
   ```bash
   git clone https://github.com/lcsavb/redcore.git
   cd redcore
   ```

2. **Set up environment variables**
   ```bash
   cp .env.example .env
   # Edit .env with your configuration
   ```

3. **Start development database**
   ```bash
   docker run -d --name redcore-db \
     --network=host \
     -e POSTGRES_DB=redcore_dev \
     -e POSTGRES_USER=redcore \
     -e POSTGRES_PASSWORD=redcore \
     postgres:16
   ```

4. **Load database schema**
   ```bash
   psql postgresql://redcore:redcore@localhost:5432/redcore_dev -f dump-red_krl5-202507081325
   ```

5. **Run the application**
   ```bash
   cargo run
   ```

The API will be available at `http://localhost:8080`

## 🧪 Testing

### Set up test database
```bash
# Copy test environment
cp .env.test.example .env.test

# Start test database
docker run -d --name redcore-test-db \
  --network=host \
  -e POSTGRES_DB=redcore_test \
  -e POSTGRES_USER=redcore \
  -e POSTGRES_PASSWORD=redcore \
  postgres:16

# Load test schema
psql postgresql://redcore:redcore@localhost:5432/redcore_test -f dump-red_krl5-202507081325
```

### Run tests
```bash
# Run all tests
cargo test

# Run specific test file
cargo test --test pre_anamnesis_integration

# Run with output
cargo test -- --nocapture
```

## 📡 API Endpoints

### 🔑 **EHR System Integration (API Key Authentication)**

**Primary Endpoint:**
#### `POST /api/appointments/make` - **PRIMARY ENDPOINT**
EHR systems call this to start patient intake workflow

**Headers:**
```
Authorization: Bearer <api-key>
Content-Type: application/json
```

**Request Body:**
```json
{
  "system_id": "uuid-string",
  "date": "ISO-8601-datetime-string",
  "patient_data": {
    "external_id": integer,
    "first_name": "string",
    "last_name": "string", 
    "date_of_birth": "YYYY-MM-DD",
    "gender": "male|female|other",
    "address": "string",
    "phone": "string",
    "email": "valid-email@example.com"
  },
  "doctor_data": {
    "external_id": integer,
    "full_name": "string",
    "specialty": "string (optional)",
    "email": "valid-email@example.com",
    "phone": "string (optional)"
  },
  "clinic_data": {
    "external_id": "string",
    "name": "string",
    "address": "string",
    "phone": "string",
    "email": "valid-email@example.com",
    "website": "string",
    "clinic_type": "Public|Private|Mixed"
  }
}
```

**Data Access:**
#### `GET /api/patients/{id}/pre-anamnesis`
Retrieve patient pre-anamnesis data for EHR systems

**Headers:**
```
Authorization: Bearer <api-key>
```

### 👤 **Patient Endpoints (JWT Token Authentication)**

#### `POST /patients/{id}/pre-anamnesis`
Submit pre-anamnesis form

**Headers:**
```
Authorization: Bearer <patient-jwt-token>
Content-Type: application/json
```

**Request Body:**
```json
{
  "chronic_disease": "string (optional)",
  "smoking": "string (optional)",
  "medicines": "string (optional)",
  "allergies": "string (optional)",
  "existing_illness": "string (optional)",
  "alcohol_drug_use": "string (optional)",
  "drug_use": "string (optional)",
  "sleep_diet": "string (optional)",
  "pregnancy_history": "string (optional)",
  "recent_exams": "binary-data (optional)",
  "recent_hospitalization": "boolean (optional)",
  "hospital_history": "string (optional)",
  "exams_passwords": "json-object (optional)"
}
```

#### `GET /patients/{id}/pre-anamnesis-token`
View own submitted pre-anamnesis

**Headers:**
```
Authorization: Bearer <patient-jwt-token>
```

### 🧑‍⚕️ **Admin Dashboard (JWT Token Authentication)**

**Authentication:**
#### `POST /auth/login`
Admin login

**Request Body:**
```json
{
  "username": "string",
  "password": "string"
}
```

#### `POST /auth/register`
User registration

**Request Body:**
```json
{
  "username": "string (3-50 chars)",
  "name": "string (4-300 chars)",
  "email": "valid-email@example.com",
  "phone": "string",
  "password": "string",
  "roles": ["admin"]
}
```

#### `POST /auth/password-reset/request`
Password recovery request

**Request Body:**
```json
{
  "email": "valid-email@example.com"
}
```

#### `POST /auth/password-reset/reset`
Password reset

**Request Body:**
```json
{
  "token": "jwt-reset-token-from-email",
  "new_password": "string"
}
```

**Dashboard & Stats:**
#### `GET /admin/patients`
View patients in database

**Headers:**
```
Authorization: Bearer <admin-jwt-token>
```

**Query Parameters:**
```
?clinic_id=uuid (optional)
?doctor_id=uuid (optional)
```

#### `GET /admin/stats`
System statistics for admin dashboard

**Headers:**
```
Authorization: Bearer <admin-jwt-token>
```

#### `GET /admin/clinics`
List clinics

**Headers:**
```
Authorization: Bearer <admin-jwt-token>
```

#### `GET /admin/doctors`
List doctors

**Headers:**
```
Authorization: Bearer <admin-jwt-token>
```

**Query Parameters:**
```
?clinic_id=uuid (optional)
```

#### `POST /admin/generate-api-key`
Generate API keys for external systems

**Headers:**
```
Authorization: Bearer <admin-jwt-token>
Content-Type: application/json
```

**Request Body:**
```json
{
  "system_id": "uuid-string",
  "permissions": ["read", "write"]
}
```

**System Management:**
- `GET /systems` - List external systems
- `GET /systems/stats` - Get system statistics

**Testing & Debug:**
#### `GET /test/protected`
Test JWT authentication

**Headers:**
```
Authorization: Bearer <jwt-token>
```

**Healthcare Provider Management:**
#### `GET /doctors/{doctor_id}/patients`
List patients for specific doctor

**Headers:**
```
Authorization: Bearer <admin-jwt-token>
```

### 🔧 **File Management & Email**

**Public (No Authentication):**
#### `POST /upload-public`
Upload appointment documents

**Form Data:**
```
file: multipart/form-data
```

#### `POST /send-email`
Send custom emails

**Request Body:**
```json
{
  "to": "email@example.com",
  "subject": "string",
  "body": "html-content"
}
```

**API Key Protected:**
#### `GET /api/files/{filename}`
Download files for external systems

**Headers:**
```
Authorization: Bearer <api-key>
```
## 🔧 Configuration

### Environment Variables

```bash
# Server Configuration
HOST=0.0.0.0
PORT=8080

# Database
DATABASE_URL=postgresql://user:password@host:port/database
MAX_DB_CONNECTIONS=5

# Authentication
JWT_SECRET_KEY=your_secret_key_here

# Email Configuration
SMTP_USERNAME=your_email@gmail.com
SMTP_PASSWORD=your_app_password
SMTP_PORT=587
SMTP_SERVER=smtp.gmail.com
FROM_EMAIL=your_email@gmail.com

# Application URLs
BASE_URL=https://your-domain.com
CHATBOT_URL=http://your-chatbot-url.com

# Development
SQLX_OFFLINE=true
```

### Test Configuration (`.env.test`)

```bash
TEST_DATABASE_URL=postgresql://redcore:redcore@localhost:5432/redcore_test
JWT_SECRET_KEY=test_secret_key_for_testing
MAX_DB_CONNECTIONS=3
SQLX_OFFLINE=true
```

## 🚀 Deployment

### 🐳 **Minimal Container Design**

RedCore uses an **optimized multi-stage Docker build** for production deployment:

**Stage 1 - Builder (`rust:1.87-alpine`):**
- Statically linked binary with musl target (`x86_64-unknown-linux-musl`)
- Dependency caching for faster rebuilds
- OpenSSL static linking for self-contained binary

**Stage 2 - Runtime (`FROM scratch`):**
- **Ultra-minimal container** - only essential files
- **~20MB final image** (vs ~1GB+ with full base image)
- Contains only: binary, CA certificates, musl loader, frontend files
- **Security**: No shell, package manager, or unnecessary tools

### 🔄 **Automated Deployment**

**GitHub Actions Pipeline:**
1. **Push to `praana` branch** → triggers build
2. **Multi-stage Docker build** → creates minimal container  
3. **Push to GHCR** → `ghcr.io/lcsavb/redcore:latest`
4. **Render deployment** → automatic via webhook

**Manual Deployment:**
```bash
docker build -t redcore .  # Creates ~20MB optimized image
docker push ghcr.io/lcsavb/redcore:latest
```

## 🏗️ Architecture

### Project Structure

```
redcore/
├── src/
│   ├── appointments/     # Appointment management
│   ├── auth/            # Authentication & authorization
│   ├── db/              # Database connection
│   ├── errors/          # Error handling
│   ├── patients/        # Patient management
│   ├── pre_anamnesis/   # Medical history collection
│   ├── routes/          # API route configuration
│   └── main.rs          # Application entry point
├── tests/               # Integration tests
├── migrations/          # Database migrations (if using)
├── .github/workflows/   # GitHub Actions
├── Dockerfile           # Container configuration
├── docker-compose.test.yml # Test database setup
└── CLAUDE.md           # Development guidelines
```

### Database Schema

The application uses PostgreSQL with the following main entities:

- **patients** - Patient information and demographics
- **pre_anamnesis** - Medical history data (13 fields: chronic_disease, smoking, medicines, allergies, etc.)
- **appointments** - Appointment scheduling triggered by EHR systems
- **healthcare_professionals** - Doctor information and credentials
- **clinics** - Clinic information and details
- **external_systems** - Third-party EHR system registration
- **api_keys** - API key management for external system access
- **users** - Admin user accounts with Argon2 password hashing
- **care_link** - Relationships between patients and healthcare providers


**Built with ❤️ using Rust and Actix-web**