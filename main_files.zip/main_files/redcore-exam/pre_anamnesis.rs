use crate::auth::jwt::validate_patient_token;
use crate::auth::middleware::AuthType;
use crate::errors::AppError;
use actix_web::{get, post, web, HttpMessage, HttpRequest, HttpResponse};
use chrono::NaiveDateTime;
use serde::{Deserialize, Serialize};
use serde_json;
use sqlx::PgPool;
use uuid::Uuid;

#[derive(Deserialize)]
pub struct PreAnamnesisInput {
    pub chronic_disease: Option<String>,
    pub smoking: Option<String>,
    pub medicines: Option<String>,
    pub allergies: Option<String>,
    pub existing_illness: Option<String>,
    pub alcohol_drug_use: Option<String>,
    pub drug_use: Option<String>,
    pub sleep_diet: Option<String>,
    pub pregnancy_history: Option<String>,
    pub recent_exams: Option<String>, 
    pub recent_hospitalization: Option<bool>,
    pub hospital_history: Option<String>,
    pub exams_passwords: Option<serde_json::Value>, // JSONB
}

#[derive(Serialize)]
pub struct PreAnamnesisOutput {
    pub id: i32,
    pub chronic_disease: Option<String>,
    pub smoking: Option<String>,
    pub medicines: Option<String>,
    pub allergies: Option<String>,
    pub existing_illness: Option<String>,
    pub alcohol_drug_use: Option<String>,
    pub drug_use: Option<String>, // Nova coluna
    pub sleep_diet: Option<String>,
    pub pregnancy_history: Option<String>,
    pub recent_exams: Option<String>, // BYTEA
    pub recent_hospitalization: Option<bool>,
    pub hospital_history: Option<String>, // Nova coluna
    pub exams_passwords: Option<serde_json::Value>, // JSONB
    pub created_at: Option<NaiveDateTime>,
    pub updated_at: Option<NaiveDateTime>,
    pub patient_id: Uuid,
}

/// Creates a pre-anamnesis (medical history questionnaire) for a specific patient.
///
/// AUTHENTICATION FLOW:
/// 1. Extracts Bearer token from Authorization header (not from middleware)
/// 2. Validates token as a patient-specific JWT (not admin JWT)  
/// 3. Ensures token belongs to the patient specified in URL path
///
/// SECURITY CRITICAL: This endpoint uses PATIENT authentication, not admin/doctor auth.
/// The patient must be authenticated and the token must match the patient_id in the URL.
/// This prevents patients from creating medical records for other patients.
///
/// MEDICAL DATA: Stores sensitive health information including:
/// - Chronic diseases, medications, allergies
/// - Substance use, pregnancy history
/// - Recent exams (binary data), hospitalizations
/// - Exam passwords (encrypted JSON data)
#[post("/{patient_id}/pre-anamnesis")]
pub async fn create(
    req: HttpRequest,
    pool: web::Data<PgPool>,
    path: web::Path<Uuid>,
    payload: web::Json<PreAnamnesisInput>,
) -> Result<HttpResponse, AppError> {
    let patient_id = path.into_inner();

    // Extract patient token from Authorization header (Bearer token)
    // NOTE: This bypasses the normal middleware because we need patient-specific validation
    let patient_token = req
        .headers()
        .get("Authorization")
        .and_then(|header| header.to_str().ok())
        .and_then(|auth_header| auth_header.strip_prefix("Bearer "))
        .ok_or(AppError::Unauthorized)?;

    // Validate patient token and extract claims
    // This uses a different validation function than admin/doctor tokens
    let patient_claims =
        validate_patient_token(patient_token).map_err(|_| AppError::Unauthorized)?;

    // CRITICAL SECURITY CHECK: Ensure the token belongs to the patient specified in the URL
    // This prevents patient A from creating medical records for patient B
    if patient_claims.sub != patient_id {
        return Err(AppError::Forbidden);
    }

    let input = payload.into_inner();

    let id = sqlx::query_file_scalar!(
        "src/sql/insert_pre_anamnesis.sql",
        input.chronic_disease,
        input.smoking,
        input.medicines,
        input.allergies,
        input.existing_illness,
        input.alcohol_drug_use,
        input.drug_use,
        input.sleep_diet,
        input.pregnancy_history,
        input.recent_exams.as_deref(),
        input.recent_hospitalization,
        input.hospital_history,
        patient_id,
        input.exams_passwords,
    )
    .fetch_one(pool.get_ref())
    .await?; // This will automatically convert SqlxError to AppError

    Ok(HttpResponse::Created().json(serde_json::json!({
        "success": true,
        "message": "Pre-anamnesis created successfully",
        "id": id
    })))
}

/// Retrieves pre-anamnesis data for a patient using API key authentication.
///
/// AUTHENTICATION MODEL: Uses API key (Authorization: Bearer <api_key>) via middleware.
/// This is designed for external system integration (e.g., clinic management systems
/// requesting patient data for appointments or medical procedures).
///
/// SECURITY ARCHITECTURE:
/// 1. Validates API key and extracts the requesting system's ID
/// 2. Verifies the patient belongs to the same system as the API key
/// 3. This prevents cross-system data access (system A cannot access system B's patients)
///
/// MULTI-TENANT ISOLATION: Critical check ensures system_id from API key matches
/// the system_id of the requested patient. This is the core security boundary
/// for preventing unauthorized cross-organization data access.
#[get("/{patient_id}/pre-anamnesis")]
pub async fn get(
    req: HttpRequest,
    pool: web::Data<PgPool>,
    path: web::Path<Uuid>,
) -> Result<HttpResponse, AppError> {
    // Extract API key info from middleware (set by api_key_validator)
    let api_key_info = {
        let extensions = req.extensions();
        extensions
            .get::<AuthType>()
            .and_then(|auth| match auth {
                AuthType::ApiKey(key) => Some(key.clone()),
                _ => None,
            })
            .ok_or_else(|| AppError::Unauthorized)?
    };
    let requesting_system_id = api_key_info.system_id;

    let patient_id = path.into_inner();

    // CRITICAL SECURITY CHECK: Verify that this system_id owns this patient
    // This prevents system A from accessing patient data that belongs to system B
    let patient_system_check =
        sqlx::query!("SELECT system_id FROM patients WHERE id = $1", patient_id)
            .fetch_optional(pool.get_ref())
            .await
            .map_err(|_| AppError::InternalError)?;

    match patient_system_check {
        Some(patient_record) => {
            if patient_record.system_id != Some(requesting_system_id) {
                return Err(AppError::Forbidden);
            }
        }
        None => {
            return Err(AppError::NotFound);
        }
    }

    let query = sqlx::query_file_as!(
        PreAnamnesisOutput,
        "src/sql/query_pre_anamnesis.sql",
        patient_id,
    )
    .fetch_one(pool.get_ref())
    .await?;

    Ok(HttpResponse::Ok().json(query))
}

#[get("{patient_id}/pre-anamnesis-token")]
pub async fn get_with_token(
    req: HttpRequest,
    pool: web::Data<PgPool>,
    path: web::Path<Uuid>,
) -> Result<HttpResponse, AppError> {
    let patient_id = path.into_inner();

    // Extract patient token from Authorization header (Bearer token)
    let patient_token = req
        .headers()
        .get("Authorization")
        .and_then(|header| header.to_str().ok())
        .and_then(|auth_header| auth_header.strip_prefix("Bearer "))
        .ok_or(AppError::Unauthorized)?;

    // Validate patient token and extract claims
    let patient_claims =
        validate_patient_token(patient_token).map_err(|_| AppError::Unauthorized)?;

    // Ensure the token belongs to the patient specified in the URL
    if patient_claims.sub != patient_id {
        return Err(AppError::Forbidden);
    }

    let query = sqlx::query_file_as!(
        PreAnamnesisOutput,
        "src/sql/query_pre_anamnesis.sql",
        patient_id,
    )
    .fetch_optional(pool.get_ref())
    .await?;

    match query {
        Some(record) => Ok(HttpResponse::Ok().json(record)),
        None => Ok(HttpResponse::NotFound().json(serde_json::json!({
            "error": "No pre-anamnesis found for this patient"
        }))),
    }
}
