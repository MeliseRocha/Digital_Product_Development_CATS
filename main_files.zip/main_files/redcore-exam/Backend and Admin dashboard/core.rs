use chrono::{DateTime, Utc};
use lettre::message::{header, Mailbox};
use lettre::{transport::smtp::authentication::Credentials, Message, SmtpTransport, Transport};
use sqlx::postgres::PgPool;
use std::env;
use tracing::{debug, error, info};
use uuid::Uuid;

use crate::auth::jwt::create_patient_jwt_token;
use crate::errors::AppError;
use crate::models::clinic::Clinic;
use crate::models::doctor::Doctor;
use crate::models::patient::{AppointmentRequest, Patient};

/// Appointment scheduling trait for different entity types.
///
/// ASYNC TRAIT DESIGN NOTE:
/// Instead of `async fn schedule()`, we use explicit Future return type for several critical reasons:
///
/// 1. **Thread Safety**: The `+ Send` bound ensures the Future can be safely transferred between
///    threads, which is essential for Tokio's multi-threaded runtime. Without this, you'd get
///    compiler errors when spawning tasks or awaiting in concurrent contexts.
///
/// 2. **Compiler Compatibility**: Explicit Future syntax avoids compilation issues that can occur
///    with `async fn` in traits, especially in older Rust versions or complex generic contexts.
///
/// 3. **Object Safety**: While this trait still can't be made into a trait object due to `impl Trait`,
///    the explicit syntax makes the limitations clear and enables better error messages.
///
/// 4. **Production Ready**: This ensures the scheduling system works reliably in production where:
///    - HTTP requests are handled across multiple threads
///    - Database operations may be spawned as background tasks  
///    - The scheduler is called from various async contexts
///
/// The implementation remains unchanged since `async fn` automatically returns a compatible Future.
pub trait Schedule {
    fn schedule(
        &self,
        pool: &PgPool,
    ) -> impl std::future::Future<Output = Result<(Uuid, String), AppError>> + Send;
}

/// Core appointment scheduling implementation with ACID transaction guarantees.
///
/// CRITICAL BUSINESS LOGIC: This is the heart of the appointment booking system.
/// It handles the complex multi-step process of creating patients, doctors, clinics,
/// and appointments in a single atomic transaction.
///
/// TRANSACTION ARCHITECTURE:
/// 1. Generate UUIDs for all entities (patient, doctor, clinic)
/// 2. Begin database transaction (ACID compliance)
/// 3. Insert/upsert clinic (handle duplicates by external_id)
/// 4. Insert/upsert doctor (linked to clinic)
/// 5. Insert/upsert patient (handle duplicate patients)
/// 6. Create patient-doctor-clinic relationship (vinculation)
/// 7. Create the actual appointment record
/// 8. Commit transaction (all-or-nothing atomicity)
/// 9. Generate patient JWT for portal access
/// 10. Send confirmation email with appointment details
///
/// FAILURE HANDLING: If ANY step fails, the entire transaction is rolled back,
/// ensuring no partial/corrupted data is left in the database.
///
/// IDEMPOTENCY: Uses "insert if missing" patterns to handle duplicate requests
/// gracefully (same external_id won't create duplicate records).
impl Schedule for AppointmentRequest {
    async fn schedule(&self, pool: &PgPool) -> Result<(Uuid, String), AppError> {
        info!("🟡 Starting ATOMIC appointment scheduling process");

        // Generate internal UUIDs for all entities in this appointment
        // These are internal primary keys, separate from external_id values from client systems
        let patient_id = Uuid::new_v4();
        let doctor_id = Uuid::new_v4();
        let clinic_id = Uuid::new_v4();

        debug!(
            "🟡 Generated UUIDs - Patient: {}, Doctor: {}, Clinic: {}",
            patient_id, doctor_id, clinic_id
        );

        // Convert API request structures to internal database models
        // This transformation separates external API contracts from internal data structures
        let patient = Patient {
            id: patient_id,
            external_id: self.patient_data.external_id, // Client system's patient ID
            system_id: self.system_id,                  // Multi-tenant isolation
            first_name: self.patient_data.first_name.clone(),
            last_name: self.patient_data.last_name.clone(),
            date_of_birth: self.patient_data.date_of_birth,
            gender: self.patient_data.gender.clone(),
            address: self.patient_data.address.clone(),
            phone: self.patient_data.phone.clone(),
            email: self.patient_data.email.clone(),
            created_at: chrono::Utc::now().naive_utc(),
        };

        let doctor = Doctor {
            id: doctor_id,
            external_id: self.doctor_data.external_id, // Client system's doctor ID
            system_id: self.system_id,                 // Same system as patient
            full_name: self.doctor_data.full_name.clone(),
            specialty: self.doctor_data.specialty.clone(),
            email: self.doctor_data.email.clone(),
            phone: self.doctor_data.phone.clone(),
            clinic_id, // Will be updated with actual clinic_id
        };

        let clinic = Clinic {
            id: clinic_id,
            system_id: self.system_id, // Multi-tenant boundary
            external_id: self.clinic_data.external_id.clone(), // Client system's clinic ID
            name: self.clinic_data.name.clone(),
            address: self.clinic_data.address.clone(),
            phone: self.clinic_data.phone.clone(),
            email: self.clinic_data.email.clone(),
            website: self.clinic_data.website.clone(),
            clinic_type: self.clinic_data.clinic_type.clone(),
            created_at: chrono::Utc::now().naive_utc(),
        };

        // BEGIN ATOMIC TRANSACTION - Critical section for data consistency
        // If ANY operation fails, ALL changes are rolled back automatically
        info!("🟡 Starting atomic transaction");
        let mut tx = pool.begin().await.map_err(AppError::from)?;

        // Step 1: Insert/upsert clinic (handles duplicates by external_id + system_id)
        info!("🟡 [TX] Inserting clinic...");
        let actual_clinic_id = sqlx::query_file!(
            "src/sql/insert_clinic_if_missing.sql",
            clinic.id,
            clinic.system_id,
            clinic.external_id,
            clinic.name,
            clinic.address,
            clinic.phone,
            clinic.email,
            clinic.website,
            clinic.clinic_type as _,
            clinic.created_at
        )
        .fetch_one(&mut *tx)
        .await
        .map_err(|e| {
            error!("🟡 [TX] ❌ Failed to insert clinic: {:?}", e);
            AppError::from(e)
        })?
        .id;

        info!("🟡 [TX] ✅ Clinic ready with ID: {}", actual_clinic_id);

        // Step 2: Insert/upsert doctor (linked to the actual clinic)
        info!("🟡 [TX] Inserting doctor...");
        let actual_doctor_id = sqlx::query_file!(
            "src/sql/insert_doctor_if_missing.sql",
            doctor.id,
            doctor.external_id,
            doctor.system_id,
            doctor.full_name,
            doctor.email,
            actual_clinic_id, // Use the actual clinic_id we just obtained
            doctor.specialty,
            doctor.phone
        )
        .fetch_one(&mut *tx)
        .await
        .map_err(|e| {
            error!("🟡 [TX] ❌ Failed to insert doctor: {:?}", e);
            AppError::from(e)
        })?
        .id;

        info!("🟡 [TX] ✅ Doctor ready with ID: {}", actual_doctor_id);

        // Step 3: Insert/upsert patient (handles duplicate patients by external_id + system_id)
        info!("🟡 [TX] Inserting patient...");
        let actual_patient_id = sqlx::query_file!(
            "src/sql/insert_patient_if_missing.sql",
            patient.id,
            patient.external_id,
            patient.system_id,
            patient.first_name,
            patient.last_name,
            patient.date_of_birth,
            patient.gender.to_string(),
            patient.address,
            patient.phone,
            patient.email,
            patient.created_at
        )
        .fetch_one(&mut *tx)
        .await
        .map_err(|e| {
            error!("🟡 [TX] ❌ Failed to insert patient: {:?}", e);
            AppError::from(e)
        })?
        .id;

        info!("🟡 [TX] ✅ Patient ready with ID: {}", actual_patient_id);

        // Step 4: Create patient-doctor-clinic relationship (vinculation)
        // This establishes which patients can see which doctors at which clinics
        info!("🟡 [TX] Vinculating patient...");
        sqlx::query_file!(
            "src/sql/vinculate_patient_if_missing.sql",
            actual_clinic_id,
            actual_patient_id,
            actual_doctor_id
        )
        .execute(&mut *tx)
        .await
        .map_err(|e| {
            error!("🟡 [TX] ❌ Failed to vinculate patient: {:?}", e);
            AppError::from(e)
        })?;

        info!("🟡 [TX] ✅ Patient vinculated");

        // Step 5: Create the actual appointment record
        info!("🟡 [TX] Creating appointment...");
        let appointment_id = sqlx::query_file!(
            "src/sql/create_appointment.sql",
            actual_clinic_id,
            actual_doctor_id,
            actual_patient_id,
            self.date
        )
        .fetch_one(&mut *tx)
        .await
        .map_err(|e| {
            error!("🟡 [TX] ❌ Failed to create appointment: {:?}", e);
            AppError::from(e)
        })?
        .id;

        info!("🟡 [TX] ✅ Appointment created with ID: {}", appointment_id);

        // COMMIT TRANSACTION - All changes become permanent
        info!("🟡 [TX] Committing transaction...");
        tx.commit().await.map_err(AppError::from)?;

        // POST-TRANSACTION OPERATIONS (these don't affect data consistency)

        // Generate patient JWT token for portal access
        let patient_token = create_patient_jwt_token(actual_patient_id, patient.gender.to_string())
            .map_err(|e| {
                error!("❌ Failed to create patient JWT token: {:?}", e);
                AppError::JWTError("Failed to create patient token".to_string())
            })?;

        // Send confirmation email with appointment details and portal access
        info!("✅ Transaction committed successfully. Sending confirmation email...");
        send_confirmation_email(
            &patient.email,
            &patient.first_name,
            &self.date,
            &doctor.full_name,
            &clinic.name,
            &patient_token, // Pass patient token for the chatbot link
        )
        .await?;

        Ok((appointment_id, patient_token))
    }
}

/// Sends a confirmation email to the patient with appointment details.
async fn send_confirmation_email(
    patient_email: &str,
    patient_name: &str,
    appointment_date: &DateTime<Utc>,
    doctor_name: &str,
    clinic_name: &str,
    patient_token: &str,
) -> Result<(), AppError> {
    info!(
        "Initiating SMTP email sending process to '{}' for patient '{}'",
        patient_email, patient_name
    );

    // SMTP Configuration from .env
    let smtp_server = env::var("SMTP_SERVER")
        .map_err(|_| AppError::ConfigError("SMTP_SERVER not set".to_string()))?;
    let smtp_port_str = env::var("SMTP_PORT")
        .map_err(|_| AppError::ConfigError("SMTP_PORT not set".to_string()))?;
    let smtp_port: u16 = smtp_port_str
        .parse()
        .map_err(|_| AppError::ConfigError(format!("Invalid SMTP_PORT: {}", smtp_port_str)))?;
    let smtp_user = env::var("SMTP_USERNAME")
        .map_err(|_| AppError::ConfigError("SMTP_USERNAME not set".to_string()))?;
    let smtp_password = env::var("SMTP_PASSWORD")
        .map_err(|_| AppError::ConfigError("SMTP_PASSWORD not set".to_string()))?;
    let from_email = env::var("FROM_EMAIL")
        .map_err(|_| AppError::ConfigError("FROM_EMAIL not set".to_string()))?;

    let formatted_date = appointment_date
        .format("%A, %d %B %Y at %H:%M UTC")
        .to_string();

    // Construct the chatbot URL with the patient's token
    let chatbot_base_url = env::var("CHATBOT_URL")
        .map_err(|_| AppError::ConfigError("CHATBOT_URL not set".to_string()))?;
    let chatbot_url = format!("{}?token={}", chatbot_base_url, patient_token);

    let html_template = include_str!("email_template.html");

    let html_content = html_template
        .replace("{patient_name}", patient_name)
        .replace("{formatted_date}", &formatted_date)
        .replace("{doctor_name}", doctor_name)
        .replace("{clinic_name}", clinic_name)
        .replace("{chatbot_url}", &chatbot_url);

    let to_mailbox: Mailbox = patient_email.parse().map_err(|e| {
        AppError::EmailError(format!(
            "Invalid patient email address '{}': {}",
            patient_email, e
        ))
    })?;
    let from_mailbox: Mailbox = from_email.parse().map_err(|e| {
        AppError::EmailError(format!(
            "Invalid FROM_EMAIL address '{}': {}",
            from_email, e
        ))
    })?;

    let email = Message::builder()
        .from(from_mailbox)
        .to(to_mailbox)
        .subject("Appointment Confirmation - Praana")
        .header(header::ContentType::TEXT_HTML)
        .body(html_content)
        .map_err(|e| AppError::EmailError(format!("Failed to build email: {}", e)))?;

    let creds = Credentials::new(smtp_user, smtp_password);

    let transport = SmtpTransport::starttls_relay(&smtp_server)
        .map_err(|e| AppError::EmailError(format!("Failed to create SMTP transport relay: {}", e)))?
        .port(smtp_port)
        .credentials(creds)
        .build();

    // Spawning a blocking task because `transport.send` is a blocking operation.
    tokio::task::spawn_blocking(move || transport.send(&email))
        .await
        .map_err(|e| AppError::EmailError(format!("Failed to execute email sending task: {}", e)))?
        .map_err(|e| AppError::EmailError(format!("Failed to send email via SMTP: {}", e)))?;

    info!("✅ Email sent successfully to {}", patient_email);
    Ok(())
}
