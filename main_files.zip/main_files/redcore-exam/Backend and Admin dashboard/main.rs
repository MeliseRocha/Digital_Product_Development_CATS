use actix_cors::Cors;
use actix_web::{web, App, HttpServer};
use db::connect_to_db;
use dotenv::dotenv;
use tracing::info;

mod admin;
mod appointments;
mod auth;
mod db;
mod doctors;
mod errors;
mod external_systems;
mod handlers;
mod models;
mod patients;
mod routes;
mod tracing_simple;

/// RedCore Healthcare Backend Server
///
/// This is the main entry point for the RedCore healthcare management system.
/// The server handles multiple authentication types and serves different user interfaces:
///
/// - External System API (API key auth): /api/*
/// - Admin Dashboard (JWT auth): /admin/*, /dashboard
/// - Patient Portal (JWT auth): /patients/*
/// - Public Assets: CSS, JS, login page
///
/// CRITICAL SECURITY NOTES:
/// - CORS is configured for development (allow_any_origin) - MUST be restricted in production
/// - JWT_SECRET_KEY environment variable must be set and cryptographically secure
/// - Database connection string should use encrypted connections in production
#[actix_web::main]
async fn main() -> std::io::Result<()> {
    // Load environment variables from .env file (development)
    dotenv().ok();

    // Initialize structured logging for request tracing and debugging
    tracing_simple::init(env!("CARGO_PKG_NAME")).expect("Failed to initialize tracing");

    // Server configuration from environment variables
    let host = std::env::var("HOST").unwrap_or_else(|_| "127.0.0.1".to_string());
    let port: u16 = std::env::var("PORT")
        .ok()
        .and_then(|port_str| port_str.parse::<u16>().ok())
        .unwrap_or(8080);

    // Establish database connection pool
    // CRITICAL: If this fails, the server cannot start
    let pool = connect_to_db().await.map_err(|e| {
        tracing::error!("❌ Database connection failed: {:?}", e);
        std::io::Error::other(e.to_string())
    })?;

    // Create HTTP server with middleware stack
    // ORDER MATTERS: Middlewares are applied in reverse order of registration
    let server = HttpServer::new(move || {
        App::new()
            .app_data(web::Data::new(pool.clone()))
            .wrap(
                // SECURITY WARNING: This CORS configuration is for DEVELOPMENT only!
                // For production, replace with specific allowed origins
                Cors::default()
                    .allow_any_origin() // TODO: Restrict to specific domains in production
                    .allow_any_method()
                    .allow_any_header()
                    .supports_credentials(),
            )
            .wrap(tracing_actix_web::TracingLogger::default()) // Request logging
            .configure(routes::config) // Main route configuration
    })
    .bind((host.as_str(), port));

    info!("🚀 Server starting on http://{}:{}", host, port);

    server.expect("Failed to bind server").run().await?;

    Ok(())
}
